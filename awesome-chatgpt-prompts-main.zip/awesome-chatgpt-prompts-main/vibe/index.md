---
title: /vibe
subtitle: awesome vibe coding prompts to help you build simple apps
hide_platform_selector: true
hide_extension_link: true
hide_tone_selector: true
subpage: true
body_class: vibe
---
